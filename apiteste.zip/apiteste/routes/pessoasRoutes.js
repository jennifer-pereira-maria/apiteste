const router = require('express').Router()

const Pessoas = require('../models/Pessoas')

//Criação de dados
router.post('/', async (req,res) =>{
    const {nome,salario,aprovado} = req.body
    //{nome:"anderson",salario:5000,aprovado:false}

    if(!nome){
        res.status(422).json({error: 'Nome é obrigatório!'})
        return
    }

    const pessoas = {
        nome,
        salario,
        aprovado
    }

    try {
        await Pessoas.create(pessoas)
        res.status(201).json({message: 'Pessoa inserida com sucesso!'})
    } catch (error) {
        res.status(500).json({error:error})
    }
})

//Leitura de dados
router.get('/', async (req, res) => {
    try {
        const pessoas = await Pessoas.find()

        res.status(200.json(pessoas)

    } catch (error) {
        res.status(500).json({ error: error })
    }
})

router.get('/:id', async (req,res) => {

    //extrair o dado da requisição pela url
    const id = req.params.id

    try {
        const pessoas = await Pessoas.findOne({ _id:id })

        if(!pessoas) {
            res.status(422).json({message: 'O usuário não foi encontrado!'})
        }

            res.status(200).json(pessoas)
    } catch (error) {
        res.status(500).json({ error: error })
    }
})

//atualização de dados
router.patch('/:id', async (req, res) => {

    const id = req.params.id

    const {nome,salario,aprovado} = req.body

    const pessoas = {
        nome,
        salario,
        aprovado,
    }

    try {
        const updatePessoas = await Pessoas.updateOne({_id:id}, pessoas)

        console.log(updatePessoas)

        if(updatePessoas.matchedCount === 0) {
            res.status(422).json({message: 'O usuário não foi encontrado!'})
            return
        }

        res.status(200).json(pessoas)

    } catch(error) {
        res.status(500).json({ error: error })
    }

})

//deletar dados
router.delete('/:id', async (req,res) => {
    const id = req.params.id

    const pessoas = await Pessoas.findOne({ _id:id })

        if(!pessoas) {
            res.status(422).json({message: 'O usuário não foi encontrado!'})
            return
        }
})

module.exports = router